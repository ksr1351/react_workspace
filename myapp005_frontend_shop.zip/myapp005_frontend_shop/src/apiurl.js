const baseUrl = 'http://localhost:8090';
const baseUrl2 = 'http://localhost:8070';

export { baseUrl, baseUrl2 };
